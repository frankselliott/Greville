GREVILLE SHADOW PHYSICAL MODEL v1.1-AB — MODEL DATA

The geometry and computed results of the model, with the SHA-256 values that
identify them as the sealed v1.1-AB release.

GEOMETRY  (coordinates in EPSG:7856, GDA2020 / MGA zone 56; levels in m AHD)

  approved_AB_model.json   The approved development as four casting volumes:
                           building A, the building B plate, the building B
                           communal roof and the building B lift overrun.
                           Footprint polygon, top RL and area for each.

  receptors.json           Private open space of the four Type G dwellings,
                           Lots 60-63 SP354191, under two readings:
                             yard   the drawn rear yard, 4.2515 m deep
                             sched  the scheduled 35 m2 band
                           Both are supported by the approved plans; neither
                           is preferred. Polygon and area for each.

  casting_edge.json        The part of the building B roof plate that casts
                           onto the receptors at the governing instants:
                           bounding box and centroid.

RESULTS

  peaks.json               Peak loss of sunlit private open space and its
                           governing instant, for every reading, fence case
                           and lot: 24 configurations. Year scanned at 5-minute
                           steps, then refined at 1 minute.

  fy_yard.log              Full-year metrics at 1-minute steps, 24
  fy_sched.log             configurations: peak, days affected, first and last
                           time affected, loss remaining at 08:00, 08:30 and
                           09:00, and the comparator's own peak at RL 48.0.

  attribution.json         Building A against building B at the peak instant,
                           8 configurations (yard, fence cases f000 and f150).

  comp_at_peaks.json       Reach of the comparator envelope at each peak
                           instant, and the lowest top RL at which it would
                           first touch the receptor: 21 configurations.

  inc2_yard_f000.log       Loss attributable to the proposal over the
  inc2_sched_f000.log      comparator, at comparator RL 48.0 and RL 55.75, fence
                           case f000. Full year at 1-minute steps between 04:00
                           and 10:00.

CONVENTIONS

  Time       Australia/Brisbane, UTC+10, no daylight saving. Calendar 2026.
  Sun        Geometric solar position, no atmospheric refraction.
  Fences     f000  no fence
             f150  1.5 m opaque fence
             f180  1.8 m opaque fence
             The approved fence is a 1500 mm metal batten fence whose opacity
             is not stated in the approved plans. f000 and f150 bound it;
             neither is the actual condition. f180 is a sensitivity case.
  Comparator A bounded eight-storey envelope family, tested at top RL 46.0 to
             55.75. It is not the applicant's model.

VERIFYING THESE FILES

  sha256sum -c MANIFEST.txt

All ten report OK.

That check relies on the MANIFEST.txt supplied here. To verify independently
of anything shipped with the data, use diff_original.py from the verification
pack published with the shadow study. It has the same ten SHA-256 values in
its own source, and recomputes the model against these files:

  python3 verify/diff_original.py <this directory>

Twelve checks, each printed: the files' hashes, the geometry vertex by vertex,
the receptor areas, and every row of every results table above.

The model's remaining inputs — receiver levels, fence lines, the four Type G
dwellings themselves, the comparator geometry and the site coordinates — are
in the same pack, in model/data/greville_model_v1.1-AB.json.

STATUS

Not expert evidence, not survey evidence, not certified. Nothing here becomes
evidence unless adopted by an appropriately qualified expert.
